import { useEffect, useMemo, useRef, useState } from "react";
import { expand, fieldsFor, matchShortcut } from "./engine.js";
import { COMMANDS, loadDb } from "./data.js";

function uid(p) { return p + Math.random().toString(36).slice(2, 7); }

export default function App() {
  const [db, setDb] = useState(loadDb);
  const [currentId, setCurrentId] = useState(db.snippets[2]?.id || db.snippets[0]?.id);
  const [query, setQuery] = useState("");
  const [preview, setPreview] = useState("Select a snippet and press Preview.");
  const [errors, setErrors] = useState([]);
  const [form, setForm] = useState(null);
  const [tab, setTab] = useState("commands");
  const contentRef = useRef(null);
  const fileRef = useRef(null);
  const current = db.snippets.find((s) => s.id === currentId) || null;

  useEffect(() => { localStorage.setItem("tb-pro", JSON.stringify(db)); }, [db]);

  function patch(partial) {
    setDb((p) => ({ ...p, snippets: p.snippets.map((s) => s.id === currentId ? { ...s, ...partial } : s) }));
  }
  function ctx(values) {
    return {
      fields: values || {}, vars: {}, user: db.user,
      site: { url: location.href, domain: location.hostname, path: location.pathname, title: document.title },
      clipboard: "", snippet: current || {},
      lookup: (key) => db.snippets.find((s) => s.shortcut === key || s.id === key || s.label === key),
    };
  }
  function withFields(template, done) {
    const fields = fieldsFor(template);
    if (fields.length) setForm({ fields, values: Object.fromEntries(fields.map((f) => [f.name, f.kind === "formtoggle" ? f.default === "yes" : f.default || ""])), done });
    else done({});
  }
  function runPreview() {
    if (!current) return;
    withFields(current.content, (values) => {
      const r = expand(current.content, ctx(values));
      const text = r.cursor == null ? r.text : r.text.slice(0, r.cursor) + "│" + r.text.slice(r.cursor);
      setPreview(text + (r.actions?.length ? `\n\n[actions: ${r.actions.map((a) => a.type).join(", ")}]` : ""));
      setErrors(r.errors || []);
    });
  }
  function onTry(e) {
    const el = e.target, start = el.selectionStart;
    const hit = matchShortcut(el.value.slice(0, start), db.snippets);
    if (!hit) return;
    withFields(hit.snippet.content, (values) => {
      const r = expand(hit.snippet.content, ctx(values));
      if (r.errors?.some((x) => x)) { setErrors(r.errors); return; }
      const next = el.value.slice(0, start - hit.shortcut.length) + r.text + el.value.slice(start);
      const pos = start - hit.shortcut.length + (r.cursor == null ? r.text.length : r.cursor);
      el.value = next; el.setSelectionRange(pos, pos);
      setDb((p) => ({ ...p, stats: { inserts: p.stats.inserts + 1, chars: p.stats.chars + Math.max(0, r.text.length - hit.shortcut.length) } }));
    });
  }
  function insert(syntax) {
    const el = contentRef.current; if (!el || !current) return;
    const s = el.selectionStart ?? current.content.length, e = el.selectionEnd ?? s;
    const content = current.content.slice(0, s) + syntax + current.content.slice(e);
    patch({ content });
    requestAnimationFrame(() => { el.focus(); el.setSelectionRange(s + syntax.length, s + syntax.length); });
  }
  const shown = query.toLowerCase();
  const grouped = useMemo(() => COMMANDS.reduce((a, c) => { (a[c.cat] ||= []).push(c); return a; }, {}), []);

  return (
    <div className="app">
      <header className="top">
        <div className="brand"><div className="mark">B</div><div>Blaze<small>local clone</small></div></div>
        <input className="search" placeholder="Search snippets" value={query} onChange={(e) => setQuery(e.target.value)} />
        <div className="stats">
          <span><b>{db.stats.inserts}</b> inserts</span>
          <span><b>{db.stats.chars.toLocaleString()}</b> chars</span>
          <span><b>{Math.round(db.stats.chars / 200)}</b> min saved</span>
        </div>
        <button className="ghost" onClick={() => setTab(tab === "settings" ? "commands" : "settings")}>Settings</button>
      </header>
      <main className="layout">
        <aside className="side">
          <div className="head">
            <h2>Snippets</h2>
            <button className="ghost" onClick={() => { const name = prompt("Folder name", "New folder"); if (name) setDb((p) => ({ ...p, folders: [...p.folders, { id: uid("f"), name, shared: false }] })); }}>Folder</button>
            <button className="btn accent" onClick={() => { const sn = { id: uid("s"), folderId: db.folders[0]?.id, label: "New snippet", shortcut: "/" + uid("").slice(0,3), content: "Hello {formtext: name=name; default=there} — {time: MMMM D, YYYY}{cursor}" }; setDb((p) => ({ ...p, snippets: [sn, ...p.snippets] })); setCurrentId(sn.id); }}>New</button>
          </div>
          <div className="list">
            {db.folders.map((folder) => {
              const items = db.snippets.filter((s) => s.folderId === folder.id && (s.label + s.shortcut).toLowerCase().includes(shown));
              return (
                <div key={folder.id}>
                  <div className={"folder-name" + (folder.shared ? " shared" : "")}>{folder.name}{folder.shared ? " · shared" : ""}</div>
                  {items.map((s) => (
                    <button key={s.id} className={"snip" + (s.id === currentId ? " on" : "")} onClick={() => setCurrentId(s.id)}>
                      <span className="sc">{s.shortcut}</span><span className="lb">{s.label}</span>
                    </button>
                  ))}
                </div>
              );
            })}
          </div>
        </aside>
        <section className="editor">
          <div className="bar">
            <label className="field grow"><span>Label</span><input value={current?.label || ""} onChange={(e) => patch({ label: e.target.value })} /></label>
            <label className="field"><span>Shortcut</span><input value={current?.shortcut || ""} onChange={(e) => patch({ shortcut: e.target.value })} /></label>
            <label className="field"><span>Folder</span>
              <select value={current?.folderId || ""} onChange={(e) => patch({ folderId: e.target.value })}>
                {db.folders.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
              </select>
            </label>
            <button className="btn" onClick={runPreview}>Preview</button>
            <button className="ghost" onClick={() => { const next = db.snippets.filter((s) => s.id !== currentId); setDb((p) => ({ ...p, snippets: next })); setCurrentId(next[0]?.id || null); }}>Delete</button>
            <button className="ghost" onClick={() => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify(db, null, 2)], { type: "application/json" })); a.download = "snippets.json"; a.click(); }}>Export</button>
            <button className="ghost" onClick={() => fileRef.current?.click()}>Import</button>
            <input ref={fileRef} hidden type="file" accept="application/json" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; const next = JSON.parse(await f.text()); setDb(next); setCurrentId(next.snippets?.[0]?.id); }} />
          </div>
          <div className="content">
            <textarea ref={contentRef} spellCheck={false} value={current?.content || ""} onChange={(e) => patch({ content: e.target.value })} />
          </div>
          <div className="preview">
            <h3>Preview</h3>
            <pre>{preview}</pre>
            {errors.length > 0 && <div className="err">{errors.join(" · ")}</div>}
          </div>
          <div className="try">
            <label className="field"><span>Try it — /ty /sig /meet /quote /support /email</span>
              <textarea placeholder="Type a shortcut…" onChange={onTry} />
            </label>
            <div className="hint">Forms open before insert. Formulas, if/else, imports, dates, and key actions all run here. Load the extension folder for site-wide expansion.</div>
          </div>
        </section>
        <aside className="cmds">
          <div className="head"><h2>{tab === "settings" ? "Settings" : "Commands"}</h2></div>
          <div className="list">
            {tab === "settings" ? (
              <>
                <label className="field"><span>Your name</span><input value={db.user.name} onChange={(e) => setDb({ ...db, user: { ...db.user, name: e.target.value } })} /></label>
                <label className="field"><span>Title</span><input value={db.user.title || ""} onChange={(e) => setDb({ ...db, user: { ...db.user, title: e.target.value } })} /></label>
                <label className="field"><span>Email</span><input value={db.user.email || ""} onChange={(e) => setDb({ ...db, user: { ...db.user, email: e.target.value } })} /></label>
                <p className="hint">Shared folders are marked in the list. Export JSON to move snippets to the Chrome extension.</p>
              </>
            ) : Object.entries(grouped).map(([cat, items]) => (
              <div key={cat}>
                <div className="cat">{cat}</div>
                {items.map((c) => (
                  <button className="cmd" key={c.name} onClick={() => insert(c.syntax)}>
                    <code>{c.syntax}</code><small>{c.help}</small>
                  </button>
                ))}
              </div>
            ))}
          </div>
        </aside>
      </main>
      {form && (
        <div className="modal-back">
          <form className="modal" onSubmit={(e) => {
            e.preventDefault();
            const values = { ...form.values };
            form.fields.forEach((f) => { if (f.kind === "formtoggle") values[f.name] = form.values[f.name] ? "yes" : "no"; });
            const missing = form.fields.filter((f) => f.required && !values[f.name]);
            if (missing.length) { setErrors(missing.map((f) => `${f.label} is required`)); return; }
            const done = form.done; setForm(null); done(values);
          }}>
            <h3>Fill snippet</h3>
            <p className="sub">These values are inserted into the template.</p>
            {form.fields.map((f) => (
              <div className="row" key={f.name}>
                {f.kind === "formtoggle" ? (
                  <label><input type="checkbox" checked={!!form.values[f.name]} onChange={(e) => setForm({ ...form, values: { ...form.values, [f.name]: e.target.checked } })} /> {f.label}</label>
                ) : (
                  <>
                    <label>{f.label}{f.required ? " *" : ""}</label>
                    {f.kind === "formparagraph" ? <textarea rows={4} value={form.values[f.name] || ""} onChange={(e) => setForm({ ...form, values: { ...form.values, [f.name]: e.target.value } })} />
                      : f.kind === "formmenu" ? <select value={form.values[f.name] || ""} onChange={(e) => setForm({ ...form, values: { ...form.values, [f.name]: e.target.value } })}>{f.options.map((o) => <option key={o}>{o}</option>)}</select>
                      : <input type={f.kind === "formdate" ? "date" : "text"} placeholder={f.placeholder} value={f.kind === "formdate" ? String(form.values[f.name] || "").slice(0, 10) : form.values[f.name] || ""} onChange={(e) => setForm({ ...form, values: { ...form.values, [f.name]: e.target.value } })} />}
                  </>
                )}
              </div>
            ))}
            <div className="actions">
              <button className="ghost" type="button" onClick={() => setForm(null)}>Cancel</button>
              <button className="btn accent" type="submit">Insert</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
