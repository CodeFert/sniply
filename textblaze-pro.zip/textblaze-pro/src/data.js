export const COMMANDS = [
  { cat: "Dates", name: "Today", syntax: "{time: MMMM D, YYYY}", help: "Current date" },
  { cat: "Dates", name: "Shifted date", syntax: "{time: MM/DD/YYYY; shift=+7 days}", help: "Date math" },
  { cat: "Forms", name: "Text", syntax: "{formtext: name=name; default=Jordan; placeholder=Name}", help: "Single-line field" },
  { cat: "Forms", name: "Paragraph", syntax: "{formparagraph: name=notes; rows=4}", help: "Multi-line field" },
  { cat: "Forms", name: "Menu", syntax: "{formmenu: Send recap; Book demo; Share pricing; name=next}", help: "Dropdown" },
  { cat: "Forms", name: "Date", syntax: "{formdate: YYYY-MM-DD; name=when}", help: "Date picker" },
  { cat: "Forms", name: "Toggle", syntax: "{formtoggle: name=include; default=yes}Optional line{endformtoggle}", help: "Checkbox section" },
  { cat: "Logic", name: "If", syntax: "{if: qty > 5}Bulk{else}Standard{endif}", help: "Conditional text" },
  { cat: "Logic", name: "Formula", syntax: "{= price * qty; format=$,.2f}", help: "Calculate" },
  { cat: "Logic", name: "Assign", syntax: "{tax=price * 0.08}", help: "Set a variable" },
  { cat: "Page", name: "Site", syntax: "{site: domain}", help: "Current site" },
  { cat: "Page", name: "Clipboard", syntax: "{clipboard}", help: "Clipboard text" },
  { cat: "Insert", name: "Cursor", syntax: "{cursor}", help: "Place the caret" },
  { cat: "Insert", name: "Import", syntax: "{import: /sig}", help: "Pull another snippet" },
  { cat: "Insert", name: "Link", syntax: "{link: https://example.com}site{endlink}", help: "Link text" },
  { cat: "Insert", name: "Repeat", syntax: "{repeat: 3}- item {= index}\n{endrepeat}", help: "Repeat a block" },
  { cat: "Auto", name: "Key", syntax: "{key: tab}", help: "Press a key" },
  { cat: "Auto", name: "Click", syntax: "{click: selector=#submit}", help: "Click an element" },
  { cat: "Auto", name: "Wait", syntax: "{wait: 1s}", help: "Pause" },
  { cat: "Meta", name: "Note", syntax: "{note}Not inserted{endnote}", help: "Hidden note" },
  { cat: "Meta", name: "Error", syntax: "{error: Name is required; block=yes}", help: "Validation" },
  { cat: "Meta", name: "User", syntax: "{user: name}", help: "Your name" },
];

export const SEED = {
  user: { name: "Alex Rivera", email: "alex@example.com", title: "Account Lead" },
  settings: { trigger: "boundary", caseSensitive: false },
  stats: { inserts: 0, chars: 0 },
  folders: [
    { id: "f1", name: "Personal", shared: false },
    { id: "f2", name: "Sales", shared: true },
    { id: "f3", name: "Support", shared: true },
  ],
  snippets: [
    { id: "s1", folderId: "f1", label: "Thank you", shortcut: "/ty", content: "Thanks for the note — I’ll follow up by {time: dddd, MMMM D}.\n{cursor}" },
    { id: "s2", folderId: "f1", label: "Signature", shortcut: "/sig", content: "Best,\n{user: name}\n{user: title}\n{time: MMMM D, YYYY}" },
    { id: "s3", folderId: "f2", label: "Meeting follow-up", shortcut: "/meet", content: "Hi {formtext: name=name; default=Jordan},\n\nGood speaking about {formtext: name=topic; default=the proposal}. Next step: {formmenu: Send recap; Book a demo; Share pricing; name=next}.\n\n{formtoggle: name=include; default=yes}I’ll send materials by {formdate: YYYY-MM-DD; name=when}.{endformtoggle}\n\n{import: /sig}" },
    { id: "s4", folderId: "f2", label: "Quote", shortcut: "/quote", content: "Quote for {formtext: name=customer; default=Northwind}\nItems: {formtext: name=qty; default=3} × ${formtext: name=price; default=120}\nSubtotal: {= qty * price; format=$,.2f}\nTax: {= qty * price * 0.08; format=$,.2f}\nTotal: {= qty * price * 1.08; format=$,.2f}\n\n{if: qty > 5}Volume discount available.{else}Standard rate.{endif}" },
    { id: "s5", folderId: "f3", label: "Support reply", shortcut: "/support", content: "Hi {formtext: name=name; default=there},\n\n{formmenu: I can help with that; I’m looking into this; This is resolved; name=status}\n\n{formparagraph: name=details; default=Here are the next steps:}\n\n{if: status = \"This is resolved\"}Glad we could close this out.{else}I’ll update you by {time: MMMM D; shift=+1 days}.{endif}\n\n{import: /sig}" },
    { id: "s6", folderId: "f2", label: "Email subject + body", shortcut: "/email", content: "{formtext: name=subject; default=Follow-up}{key: tab}Hi {formtext: name=name; default=Jordan},\n\n{formparagraph: name=body; default=Quick note on our conversation.}\n\n{import: /sig}" },
  ],
};

export function loadDb() {
  try { return JSON.parse(localStorage.getItem("tb-pro")) || structuredClone(SEED); }
  catch { return structuredClone(SEED); }
}
