chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: "tb", title: "Insert snippet", contexts: ["editable"] });
});
