(function () {
  if (window.__tb) return;
  window.__tb = true;
  let db = { snippets: [], user: {}, stats: { inserts: 0, chars: 0 } };
  chrome.storage.local.get("tb", (d) => { if (d.tb) db = d.tb; });
  chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.tb) db = ch.tb.newValue; });
  let busy = false;
  document.addEventListener("input", onInput, true);

  function onInput(e) {
    if (busy) return;
    const el = e.target;
    if (!el || !db.snippets || (el.closest && el.closest("#tb-root"))) return;
    if (!(el.matches && (el.matches("input, textarea") || el.isContentEditable))) return;
    const info = read(el);
    if (!info) return;
    const hit = TBEngine.matchShortcut(info.before, db.snippets);
    if (!hit) return;
    const fields = TBEngine.fieldsFor(hit.snippet.content);
    const go = (values) => insert(el, info, hit, values);
    if (fields.length) ask(fields, go); else go({});
  }
  function insert(el, info, hit, values) {
    busy = true;
    try {
      const r = TBEngine.expand(hit.snippet.content, {
        fields: values, vars: {}, user: db.user || {},
        site: { url: location.href, domain: location.hostname, path: location.pathname, title: document.title },
        clipboard: "", snippet: hit.snippet,
        lookup: (key) => db.snippets.find((s) => s.shortcut === key || s.id === key),
      });
      write(el, info, hit.shortcut.length, r.text, r.cursor);
      db.stats = db.stats || { inserts: 0, chars: 0 };
      db.stats.inserts += 1;
      db.stats.chars += Math.max(0, r.text.length - hit.shortcut.length);
      chrome.storage.local.set({ tb: db });
      (r.actions || []).forEach((a) => { if (a.type === "click" && a.selector) document.querySelector(a.selector)?.click(); });
    } finally { setTimeout(() => { busy = false; }, 0); }
  }
  function read(el) {
    if (el.isContentEditable) {
      const sel = getSelection(); if (!sel || !sel.rangeCount) return null;
      const range = sel.getRangeAt(0); if (!el.contains(range.endContainer)) return null;
      const pre = range.cloneRange(); pre.selectNodeContents(el); pre.setEnd(range.endContainer, range.endOffset);
      return { before: pre.toString(), editable: true, range };
    }
    if (typeof el.selectionStart !== "number") return null;
    return { before: el.value.slice(0, el.selectionStart), start: el.selectionStart };
  }
  function write(el, info, scLen, text, cursor) {
    if (info.editable) {
      const node = info.range.endContainer;
      if (node.nodeType === Node.TEXT_NODE) {
        const end = info.range.endOffset, start = end - scLen;
        node.textContent = node.textContent.slice(0, start) + text + node.textContent.slice(end);
        const pos = start + (cursor == null ? text.length : cursor);
        const r = document.createRange(); r.setStart(node, Math.min(pos, node.textContent.length)); r.collapse(true);
        const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
      }
      return;
    }
    const start = info.start - scLen;
    el.value = el.value.slice(0, start) + text + el.value.slice(info.start);
    const pos = start + (cursor == null ? text.length : cursor);
    el.setSelectionRange(pos, pos);
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }
  function ask(fields, done) {
    const root = document.createElement("div");
    root.id = "tb-root";
    const shadow = root.attachShadow({ mode: "open" });
    shadow.innerHTML = `<style>
      .back{position:fixed;inset:0;background:rgba(28,25,23,.45);z-index:2147483646;display:flex;align-items:center;justify-content:center;font-family:Segoe UI,sans-serif}
      .box{width:min(520px,calc(100% - 24px));background:#fff;color:#1c1917;border-radius:14px;padding:16px}
      h3{margin:0 0 10px;font-size:16px} label{display:block;font-size:13px;font-weight:600;margin:8px 0 4px}
      input,textarea,select{width:100%;box-sizing:border-box;border:1px solid #e7e5e4;border-radius:8px;padding:8px;font:inherit}
      .row{display:flex;justify-content:flex-end;gap:8px;margin-top:12px}
      button{border-radius:8px;padding:8px 12px;border:1px solid #e7e5e4;background:#fff;cursor:pointer}
      .go{background:#ea580c;color:#fff;border-color:#ea580c}
    </style><div class="back"><form class="box"><h3>Fill snippet</h3><div id="fields"></div><div class="row"><button type="button" id="cancel">Cancel</button><button class="go" type="submit">Insert</button></div></form></div>`;
    const host = shadow.getElementById("fields");
    host.innerHTML = fields.map((f) => {
      if (f.kind === "formparagraph") return `<label>${f.label}</label><textarea data-name="${f.name}">${f.default || ""}</textarea>`;
      if (f.kind === "formmenu") return `<label>${f.label}</label><select data-name="${f.name}">${(f.options||[]).map((o)=>`<option ${o===f.default?"selected":""}>${o}</option>`).join("")}</select>`;
      if (f.kind === "formtoggle") return `<label><input type="checkbox" data-name="${f.name}" ${f.default==="yes"?"checked":""}/> ${f.label}</label>`;
      if (f.kind === "formdate") return `<label>${f.label}</label><input type="date" data-name="${f.name}" value="${String(f.default).slice(0,10)}"/>`;
      return `<label>${f.label}</label><input data-name="${f.name}" value="${f.default || ""}" placeholder="${f.placeholder || ""}"/>`;
    }).join("");
    document.documentElement.appendChild(root);
    host.querySelector("input,textarea,select")?.focus();
    shadow.getElementById("cancel").onclick = () => root.remove();
    shadow.querySelector("form").onsubmit = (ev) => {
      ev.preventDefault();
      const values = {};
      host.querySelectorAll("[data-name]").forEach((el) => { values[el.dataset.name] = el.type === "checkbox" ? (el.checked ? "yes" : "no") : el.value; });
      root.remove(); done(values);
    };
  }
})();
