import { useEffect, useMemo, useRef, useState } from "react";
import { expand, fieldsFor, matchShortcut } from "./engine.js";
import { COMMANDS, loadDb } from "./data.js";

function uid(p) { return p + Math.random().toString(36).slice(2, 7); }

export default function App() {
  const [db, setDb] = useState(loadDb);
  const [currentId, setCurrentId] = useState(db.snippets[0]?.id);
  const [query, setQuery] = useState("");
  const [mode, setMode] = useState("edit");
  const [previewText, setPreviewText] = useState("");
  const [previewFields, setPreviewFields] = useState([]);
  const [errors, setErrors] = useState([]);
  const [form, setForm] = useState(null);
  const [tab, setTab] = useState("commands");
  const contentRef = useRef(null);
  const fileRef = useRef(null);
  const current = db.snippets.find((s) => s.id === currentId) || null;

  useEffect(() => { localStorage.setItem("tb-pro", JSON.stringify(db)); }, [db]);

  function patch(partial) {
    setDb((p) => ({ ...p, snippets: p.snippets.map((s) => s.id === currentId ? { ...s, ...partial } : s) }));
  }
  function ctx(values) {
    return {
      fields: values || {}, vars: {}, user: db.user,
      site: { url: location.href, domain: location.hostname, path: location.pathname, title: document.title },
      clipboard: "", snippet: current || {},
      lookup: (key) => db.snippets.find((s) => s.shortcut === key || s.id === key || s.label === key),
    };
  }
  function withFields(template, done) {
    const fields = fieldsFor(template);
    if (fields.length) setForm({ fields, values: Object.fromEntries(fields.map((f) => [f.name, f.kind === "formtoggle" ? f.default === "yes" : f.default || ""])), done });
    else done({});
  }
  function runPreview() {
    if (!current) return;
    withFields(current.content, (values) => {
      const fields = fieldsFor(current.content);
      setPreviewFields(fields);
      const r = expand(current.content, ctx(values));
      setPreviewText(r.text);
      setErrors(r.errors || []);
      setMode("preview");
    });
  }
  function onTry(e) {
    const el = e.target, start = el.selectionStart;
    const hit = matchShortcut(el.value.slice(0, start), db.snippets);
    if (!hit) return;
    withFields(hit.snippet.content, (values) => {
      const r = expand(hit.snippet.content, ctx(values));
      if (r.errors?.some((x) => x)) { setErrors(r.errors); return; }
      const next = el.value.slice(0, start - hit.shortcut.length) + r.text + el.value.slice(start);
      const pos = start - hit.shortcut.length + (r.cursor == null ? r.text.length : r.cursor);
      el.value = next; el.setSelectionRange(pos, pos);
      setDb((p) => ({ ...p, stats: { inserts: p.stats.inserts + 1, chars: p.stats.chars + Math.max(0, r.text.length - hit.shortcut.length) } }));
    });
  }
  function insert(syntax) {
    const el = contentRef.current; if (!el || !current) return;
    const s = el.selectionStart ?? current.content.length, e = el.selectionEnd ?? s;
    const content = current.content.slice(0, s) + syntax + current.content.slice(e);
    patch({ content });
    requestAnimationFrame(() => { el.focus(); el.setSelectionRange(s + syntax.length, s + syntax.length); });
  }
  const shown = query.toLowerCase();
  const grouped = useMemo(() => COMMANDS.reduce((a, c) => { (a[c.cat] ||= []).push(c); return a; }, {}), []);

  return (
    <div className="app">
      <header className="top">
        <div className="brand"><div className="mark">⚡</div> sniply<span className="tag">Type less, Say more.</span></div>
        <input className="search" placeholder="Search snippets" value={query} onChange={(e) => setQuery(e.target.value)} />
        <div className="stats">
          <span>Less typing. More doing.</span>
        </div>
        <button className="ghost-light" onClick={() => setTab(tab === "settings" ? "commands" : "settings")}>Settings</button>
      </header>
      <main className="layout">
        <aside className="side">
          <div className="head">
            <h2>Snippets</h2>
            <button className="ghost" onClick={() => { const name = prompt("Folder name", "New folder"); if (name) setDb((p) => ({ ...p, folders: [...p.folders, { id: uid("f"), name, shared: false }] })); }}>Folder</button>
            <button className="btn accent" onClick={() => { const sn = { id: uid("s"), folderId: db.folders[0]?.id, label: "New Snippet", shortcut: "/" + uid("").slice(0,3), content: "Hello {formtext: name=name; default=there}" }; setDb((p) => ({ ...p, snippets: [sn, ...p.snippets] })); setCurrentId(sn.id); setMode("edit"); }}>New</button>
          </div>
          <div className="list">
            {db.folders.map((folder) => {
              const items = db.snippets.filter((s) => s.folderId === folder.id && (s.label + s.shortcut).toLowerCase().includes(shown));
              return (
                <div key={folder.id}>
                  <div className="folder-name">{folder.name}</div>
                  {items.map((s) => (
                    <button key={s.id} className={"snip" + (s.id === currentId ? " on" : "")} onClick={() => { setCurrentId(s.id); setMode("edit"); }}>
                      <span className="lb">{s.label}</span><span className="sc">{s.shortcut}</span>
                    </button>
                  ))}
                </div>
              );
            })}
          </div>
        </aside>
        <section className="editor">
          <div className="meta">
            <label className="field grow"><span>Label</span><input value={current?.label || ""} onChange={(e) => patch({ label: e.target.value })} /></label>
            <label className="field" style={{width:180}}><span>Shortcut</span><input value={current?.shortcut || ""} onChange={(e) => patch({ shortcut: e.target.value })} /></label>
            <div className="mode">
              <button className={"btn" + (mode==="edit"?" accent":"")} onClick={() => setMode("edit")}>Edit</button>
              <button className={"btn" + (mode==="preview"?" accent":"")} onClick={runPreview}>Preview</button>
            </div>
          </div>
          {mode === "edit" ? (
            <>
              <div className="toolbar">
                <button title="Bold" onClick={() => insert("**bold**")}>B</button>
                <button title="Italic" onClick={() => insert("*italic*")}>I</button>
                <button title="Underline" onClick={() => insert("<u>underline</u>")}>U</button>
                <span className="hint" style={{marginLeft:8}}>Click a command on the right to insert it</span>
                <button className="ghost" style={{marginLeft:"auto"}} onClick={() => { const next = db.snippets.filter((s) => s.id !== currentId); setDb((p) => ({ ...p, snippets: next })); setCurrentId(next[0]?.id || null); }}>Delete</button>
              </div>
              <div className="sheet">
                <textarea ref={contentRef} spellCheck={false} value={current?.content || ""} onChange={(e) => patch({ content: e.target.value })} />
              </div>
            </>
          ) : (
            <div className="sheet" style={{marginTop:12}}>
              <div className="preview-body">
                {(previewText || "").split("\n").map((line, i) => (
                  <p key={i}>{line || "\u00a0"}</p>
                ))}
                {previewFields.length > 0 && (
                  <div style={{marginTop:16,paddingTop:12,borderTop:"1px solid var(--line)"}}>
                    <div className="cat" style={{paddingLeft:0}}>Fields used</div>
                    {previewFields.map((f) => (
                      <span key={f.name} className="chip" style={{margin:"0 6px 6px 0"}}>{f.name}</span>
                    ))}
                  </div>
                )}
                {errors.length > 0 && <div className="err">{errors.join(" · ")}</div>}
              </div>
            </div>
          )}
          <div className="try">
            <label className="field"><span>Try a shortcut</span>
              <textarea placeholder="Type /sig or /pgt+ then a space" onChange={onTry} />
            </label>
          </div>
        </section>
        <aside className="cmds">
          <div className="head"><h2>{tab === "settings" ? "Settings" : "Commands"}</h2></div>
          <div className="list">
            {tab === "settings" ? (
              <>
                <label className="field"><span>Your name</span><input value={db.user.name} onChange={(e) => setDb({ ...db, user: { ...db.user, name: e.target.value } })} /></label>
                <label className="field"><span>Title</span><input value={db.user.title || ""} onChange={(e) => setDb({ ...db, user: { ...db.user, title: e.target.value } })} /></label>
                <p className="hint">Export JSON from the editor to use with the Chrome extension.</p>
              </>
            ) : Object.entries(grouped).map(([cat, items]) => (
              <div key={cat}>
                <div className="cat">{cat}</div>
                {items.map((c) => (
                  <button className="cmd" key={c.name} onClick={() => { insert(c.syntax); setMode("edit"); }}>
                    <b>{c.name}</b><small>{c.help}</small>
                  </button>
                ))}
              </div>
            ))}
          </div>
        </aside>
      </main>
      {form && (
        <div className="modal-back">
          <form className="modal" onSubmit={(e) => {
            e.preventDefault();
            const values = { ...form.values };
            form.fields.forEach((f) => { if (f.kind === "formtoggle") values[f.name] = form.values[f.name] ? "yes" : "no"; });
            const done = form.done; setForm(null); done(values);
          }}>
            <h3>Fill snippet</h3>
            <p className="sub">These values are inserted into the template.</p>
            {form.fields.map((f) => (
              <div className="row" key={f.name}>
                {f.kind === "formtoggle" ? (
                  <label><input type="checkbox" checked={!!form.values[f.name]} onChange={(e) => setForm({ ...form, values: { ...form.values, [f.name]: e.target.checked } })} /> {f.label}</label>
                ) : (
                  <>
                    <label>{f.label}</label>
                    {f.kind === "formparagraph" ? <textarea rows={4} value={form.values[f.name] || ""} onChange={(e) => setForm({ ...form, values: { ...form.values, [f.name]: e.target.value } })} />
                      : f.kind === "formmenu" ? (
                        <select
                          value={form.values[f.name] ?? f.default ?? (f.options[0] || "")}
                          onChange={(e) => setForm((prev) => ({ ...prev, values: { ...prev.values, [f.name]: e.target.value } }))}
                        >
                          {(f.options.length ? f.options : ["Option 1", "Option 2"]).map((o) => <option key={o} value={o}>{o}</option>)}
                        </select>
                      )
                      : <input type={f.kind === "formdate" ? "date" : "text"} placeholder={f.placeholder} value={form.values[f.name] || ""} onChange={(e) => setForm({ ...form, values: { ...form.values, [f.name]: e.target.value } })} />}
                  </>
                )}
              </div>
            ))}
            <div className="actions">
              <button className="ghost" type="button" onClick={() => setForm(null)}>Cancel</button>
              <button className="btn accent" type="submit">Insert</button>
            </div>
          </form>
        </div>
      )}
      <input ref={fileRef} hidden type="file" accept="application/json" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; const next = JSON.parse(await f.text()); setDb(next); setCurrentId(next.snippets?.[0]?.id); }} />
    </div>
  );
}
