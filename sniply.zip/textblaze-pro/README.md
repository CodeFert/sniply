# Text Blaze clone

Closer local recreation of the Text Blaze workflow. Not affiliated with blaze.today.

## Run
```
npm install
npm run dev
```

## Extension
Load this folder unpacked at chrome://extensions, then copy `src/engine.js` to `extension/engine.js` is already included if you copy it. The dashboard is the web app; export JSON and the extension reads `chrome.storage` if you point them at the same data.

## Included
Folders, shortcuts, forms, menus, dates, toggles, if/else, formulas with format, imports, site data, clipboard, cursor, repeat, key/click/wait actions, notes, validation errors, stats, export/import.
